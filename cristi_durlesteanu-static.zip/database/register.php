<?php
require 'db.php';
session_start();

$message = "";

// 1. Handle Registration
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    if ($stmt->execute([$username, $password])) {
        $_SESSION['user_id'] = $pdo->lastInsertId();
        $_SESSION['username'] = $username;
        $message = "Registration successful! You are now logged in.";
    }
}

// 2. Handle Testimonial Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_testimonial'])) {
    $stmt = $pdo->prepare("INSERT INTO testimonials (user_id, content) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $_POST['content']]);
    $message = "Testimonial posted!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; display: flex; justify-content: center; padding: 50px; }
        .container { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 350px; }
        input, textarea { width: 100%; margin: 10px 0; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .msg { color: green; font-size: 0.9em; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <p class="msg"><?php echo $message; ?></p>
        
        <?php if (!isset($_SESSION['user_id'])): ?>
            <h3>Register</h3>
            <form method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="register">Register</button>
            </form>
        <?php else: ?>
            <h3>Post a Testimonial</h3>
            <form method="POST">
                <textarea name="content" placeholder="Your review..." required></textarea>
                <button type="submit" name="add_testimonial">Submit</button>
            </form>
            <p><a href="?logout=1">Logout</a></p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php 
if (isset($_GET['logout'])) { session_destroy(); header("Location: register.php"); }
?>