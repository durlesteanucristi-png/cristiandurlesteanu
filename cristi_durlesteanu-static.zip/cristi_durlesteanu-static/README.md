# Arlene Rey — Portfolio (STATIC version)

A pure **HTML + CSS + JavaScript** version of the portfolio. **No PHP, no database, no XAMPP needed.**

## How to run
Just **double-click `index.html`** — it opens in your browser and works offline.
(You can also serve it through Apache at `http://localhost/cristi_durlesteanu-static/` if you prefer.)

## What works
- ✅ Full responsive design (desktop + mobile)
- ✅ **Mobile hamburger menu** (open/close)
- ✅ **Testimonials carousel** in Section 3 — prev/next arrows, dots, keyboard ←/→, swipe, autoplay
- ✅ Smooth-scroll navigation (About → top, Testimonials → Section 3)
- ✅ Mail Me / Contact Me buttons (open the mail client)
- ✅ Login / Register pages (design only — they show a notice since there is no server)

## Files
```
index.html       Homepage (all content hard-coded into the HTML)
login.html       Login form (design only)
register.html    Register form (design only)
css/             reset.css, global.css, portfolio.css, style.css
js/main.js       Mobile menu + interactive carousel
assets/          Images
```

## Difference vs. the PHP version
| | Static (this folder) | PHP version (`cristi_durlesteanu`) |
|---|---|---|
| Content | Hard-coded in HTML | Loaded from MySQL database |
| Login / Register | Design only | Real accounts (sessions, hashed passwords) |
| Admin / CRUD | None | Add / edit / delete testimonials + edit Section 2 |
| Needs a server | No | Yes (Apache + MySQL) |

Use this version when you just want to show the **design with working interactive buttons**.
Use the PHP version for the full database-driven app.
