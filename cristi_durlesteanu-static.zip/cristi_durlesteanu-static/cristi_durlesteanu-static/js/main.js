/* ============================================================
   main.js
   - Mobile hamburger navigation
   - Section 3 interactive testimonials carousel
     (responsive pages, dots, prev/next, keyboard, swipe, autoplay)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {

	/* ---------------- Mobile navigation ---------------- */
	var navToggle = document.getElementById('navToggle');
	var navMenu = document.getElementById('navMenu');

	if (navToggle && navMenu) {
		navToggle.addEventListener('click', function () {
			var open = navMenu.classList.toggle('open');
			navToggle.classList.toggle('open', open);
			navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
		navMenu.querySelectorAll('a').forEach(function (link) {
			link.addEventListener('click', function () {
				navMenu.classList.remove('open');
				navToggle.classList.remove('open');
				navToggle.setAttribute('aria-expanded', 'false');
			});
		});
	}

	/* ---------------- Testimonials carousel ---------------- */
	var track = document.getElementById('testimonialTrack');
	if (!track) return;

	var carousel = document.getElementById('carousel');
	var dotsWrap = document.getElementById('carouselDots');
	var prevBtn = document.getElementById('carouselPrev');
	var nextBtn = document.getElementById('carouselNext');

	var allCards = Array.prototype.slice.call(track.querySelectorAll('.card-testimonial'));
	var current = 0;
	var pages = 0;
	var perView = 2;
	var autoTimer = null;
	var AUTO_MS = 6000;

	function getPerView() {
		return window.innerWidth <= 768 ? 1 : 2;
	}

	/* Build responsive pages + matching dots from the flat card list. */
	function build() {
		perView = getPerView();
		track.innerHTML = '';
		pages = Math.max(1, Math.ceil(allCards.length / perView));

		for (var p = 0; p < pages; p++) {
			var page = document.createElement('div');
			page.className = 'carousel-page';
			for (var i = p * perView; i < Math.min((p + 1) * perView, allCards.length); i++) {
				page.appendChild(allCards[i]);
			}
			track.appendChild(page);
		}

		dotsWrap.innerHTML = '';
		for (var d = 0; d < pages; d++) {
			var dot = document.createElement('button');
			dot.className = 'carousel-dot';
			dot.type = 'button';
			dot.setAttribute('aria-label', 'Go to slide ' + (d + 1));
			(function (idx) {
				dot.addEventListener('click', function () { goTo(idx); resetAuto(); });
			})(d);
			dotsWrap.appendChild(dot);
		}

		if (current >= pages) current = pages - 1;
		update();
	}

	function update() {
		track.style.transform = 'translateX(' + (-current * 100) + '%)';
		var dots = dotsWrap.children;
		for (var i = 0; i < dots.length; i++) {
			dots[i].classList.toggle('active', i === current);
		}
	}

	function goTo(i) { current = Math.max(0, Math.min(i, pages - 1)); update(); }
	function next() { current = (current + 1) % pages; update(); }
	function prev() { current = (current - 1 + pages) % pages; update(); }

	if (nextBtn) nextBtn.addEventListener('click', function () { next(); resetAuto(); });
	if (prevBtn) prevBtn.addEventListener('click', function () { prev(); resetAuto(); });

	/* Keyboard arrows (ignore while typing in a field) */
	document.addEventListener('keydown', function (e) {
		var tag = (e.target.tagName || '').toLowerCase();
		if (tag === 'input' || tag === 'textarea') return;
		if (e.key === 'ArrowRight') { next(); resetAuto(); }
		else if (e.key === 'ArrowLeft') { prev(); resetAuto(); }
	});

	/* Autoplay (pauses on hover) */
	function startAuto() {
		if (pages <= 1) return;
		autoTimer = setInterval(next, AUTO_MS);
	}
	function resetAuto() { clearInterval(autoTimer); startAuto(); }

	if (carousel) {
		carousel.addEventListener('mouseenter', function () { clearInterval(autoTimer); });
		carousel.addEventListener('mouseleave', startAuto);
	}

	/* Touch swipe */
	var startX = 0, deltaX = 0, dragging = false;
	track.addEventListener('touchstart', function (e) {
		startX = e.touches[0].clientX; dragging = true; clearInterval(autoTimer);
	}, { passive: true });
	track.addEventListener('touchmove', function (e) {
		if (dragging) deltaX = e.touches[0].clientX - startX;
	}, { passive: true });
	track.addEventListener('touchend', function () {
		if (Math.abs(deltaX) > 50) { (deltaX < 0 ? next : prev)(); }
		dragging = false; deltaX = 0; resetAuto();
	});

	/* Rebuild when the cards-per-view threshold changes */
	var resizeTimer;
	window.addEventListener('resize', function () {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function () {
			if (getPerView() !== perView) build();
		}, 150);
	});

	build();
	startAuto();
});
