# Arlene Rey — Portfolio (cristi_durlesteanu)

A functional portfolio website built with **PHP + MySQL (MariaDB)** on XAMPP.
The static HTML/CSS design was turned into a dynamic, database-driven, responsive
site with user authentication and a full CRUD admin dashboard. All content is in **English**.

## Run it

1. Make sure **Apache** and **MySQL** are running in XAMPP.
2. Import the database (creates the `cristi_durlesteanu` database, tables and seed data):

   ```
   C:\xampp\mysql\bin\mysql.exe -u root < sql\cristi_durlesteanu.sql
   ```

   (or import `sql/cristi_durlesteanu.sql` through phpMyAdmin).
3. Open: **http://localhost/cristi_durlesteanu/index.php**

### Demo login
- **Email:** `admin@cristi.com`
- **Password:** `admin123`

You can also create your own account on the **Register** page.

## Structure

```
cristi_durlesteanu/
├── index.php          Public homepage (menu + 3 sections + footer), reads from DB
├── login.php          Log in (sessions)
├── register.php       Register a new account
├── logout.php         Destroy session
├── admin.php          Protected dashboard — CRUD + Section 2 editor
├── config/db.php      PDO database connection
├── includes/helpers.php  Sessions, escaping, auth checks, star rendering
├── css/               reset.css, global.css, portfolio.css (design), style.css, admin.css
├── js/main.js         Mobile menu + interactive testimonials carousel
└── sql/cristi_durlesteanu.sql   Database schema + seed data
```

## Database (`cristi_durlesteanu`)

| Table          | Purpose                                              |
|----------------|------------------------------------------------------|
| `users`        | Login / register (passwords hashed with `password_hash`) |
| `site_info`    | **Section 2** "Review" content (editable from the dashboard) |
| `testimonials` | **Section 3** testimonials shown in the carousel (full CRUD) |

The homepage pulls Section 2 **and** Section 3 content live from the database.

## How it maps to the assessment criteria

| Criterion | Where |
|-----------|-------|
| 1.1 Insert menu | `index.php` — `.header-nav-bar` (About / Testimonials / Log In) |
| 1.2 Section 1 elements | Hero header (`#section1`) |
| 1.3 Section 2 elements | Review block (`#section2`) |
| 1.4 Section 3 elements | Testimonials (`#section3`) |
| 1.5 Menu formatting | `portfolio.css` + `style.css` (nav styles) |
| 1.6 Section 1 formatting | `portfolio.css` (`.header-*`) |
| 1.7 Section 2 formatting | `portfolio.css` (`.info-*`) + dynamic stars |
| 1.8 Section 3 formatting | `portfolio.css` + `style.css` (`.card-testimonial-*`, carousel) |
| 2.1 Footer | `<footer class="site-footer">` in `index.php` |
| 2.2 Footer formatting | `style.css` (`.site-footer*`) |
| 3.1 Mobile responsive | `style.css` media queries + hamburger menu (`js/main.js`) |
| 3.2 Section 3 interactivity | Testimonials carousel: dots, prev/next, keyboard, swipe, autoplay (`js/main.js`) |
| 4.1 Database created | `sql/cristi_durlesteanu.sql` |
| 4.2 DB connection | `config/db.php` (PDO) |
| 4.3 Pages read from DB | Section 2 (`site_info`) + Section 3 (`testimonials`) on `index.php` |
| 5.1 Read | `admin.php` testimonials table + Section 2 form |
| 5.2 Add (Create) | `admin.php` "Add testimonial" |
| 5.3 Edit (Update) | `admin.php` "Edit testimonial" + "Save Section 2" |
| 5.4 Delete | `admin.php` "Delete" button |

## Security notes
- Passwords are hashed (`password_hash` / `password_verify`).
- All database access uses **prepared statements** (PDO).
- All output is escaped (`htmlspecialchars`) to prevent XSS.
- The dashboard is session-protected and forms use a **CSRF token**.
