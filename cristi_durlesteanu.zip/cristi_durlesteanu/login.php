<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

if (is_logged_in()) {
    header('Location: admin.php');
    exit;
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $errors[] = 'Please enter your email and password.';
    } else {
        $stmt = $pdo->prepare('SELECT id, name, password FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = (int) $user['id'];
            $_SESSION['user_name'] = $user['name'];
            header('Location: admin.php');
            exit;
        }
        $errors[] = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Log In — Arlene Rey</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>
	<main class="auth-page">
		<div class="auth-card">
			<h1>Welcome back</h1>
			<p class="auth-sub">Log in to manage the portfolio content.</p>

			<?php if ($errors): ?>
				<div class="alert alert-error">
					<?php foreach ($errors as $err): ?>
						<div><?= e($err) ?></div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<form method="post" action="login.php" novalidate>
				<div class="field">
					<label for="email">Email</label>
					<input type="email" id="email" name="email" value="<?= e($email) ?>" placeholder="you@example.com" required />
				</div>
				<div class="field">
					<label for="password">Password</label>
					<input type="password" id="password" name="password" placeholder="Your password" required />
				</div>
				<button type="submit" class="btn-primary">Log in</button>
			</form>

			<p class="auth-foot">Don't have an account? <a href="register.php">Register</a></p>
			<div class="alert alert-success" style="margin-top:18px;margin-bottom:0">
				<strong>Demo account</strong><br />
				Email: admin@cristi.com<br />
				Password: admin123
			</div>
			<div style="text-align:center"><a class="back-home" href="index.php">&larr; Back to website</a></div>
		</div>
	</main>
</body>
</html>
