<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

if (is_logged_in()) {
    header('Location: admin.php');
    exit;
}

$errors = [];
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($name === '') {
        $errors[] = 'Please enter your name.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }
    if ($password !== $confirm) {
        $errors[] = 'The passwords do not match.';
    }

    if (!$errors) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);

        if ($check->fetch()) {
            $errors[] = 'An account with this email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
            $insert->execute([$name, $email, $hash]);

            // auto-login the new user
            $_SESSION['user_id']   = (int) $pdo->lastInsertId();
            $_SESSION['user_name'] = $name;

            header('Location: admin.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Create Account — Arlene Rey</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/style.css" />
</head>
<body>
	<main class="auth-page">
		<div class="auth-card">
			<h1>Create account</h1>
			<p class="auth-sub">Register to manage the portfolio content.</p>

			<?php if ($errors): ?>
				<div class="alert alert-error">
					<?php foreach ($errors as $err): ?>
						<div><?= e($err) ?></div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<form method="post" action="register.php" novalidate>
				<div class="field">
					<label for="name">Full name</label>
					<input type="text" id="name" name="name" value="<?= e($name) ?>" placeholder="Jane Doe" required />
				</div>
				<div class="field">
					<label for="email">Email</label>
					<input type="email" id="email" name="email" value="<?= e($email) ?>" placeholder="you@example.com" required />
				</div>
				<div class="field">
					<label for="password">Password</label>
					<input type="password" id="password" name="password" placeholder="At least 6 characters" required />
				</div>
				<div class="field">
					<label for="confirm">Confirm password</label>
					<input type="password" id="confirm" name="confirm" placeholder="Repeat your password" required />
				</div>
				<button type="submit" class="btn-primary">Create account</button>
			</form>

			<p class="auth-foot">Already have an account? <a href="login.php">Log in</a></p>
			<div style="text-align:center"><a class="back-home" href="index.php">&larr; Back to website</a></div>
		</div>
	</main>
</body>
</html>
