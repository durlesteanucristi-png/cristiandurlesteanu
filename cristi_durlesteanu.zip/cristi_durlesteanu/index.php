<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

// ----- SECTION 2 data (from database) -----
$info = $pdo->query('SELECT * FROM site_info ORDER BY id LIMIT 1')->fetch();

// ----- SECTION 3 data (from database) -----
$testimonials = $pdo->query('SELECT * FROM testimonials ORDER BY id ASC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Arlene Rey — UI/UX Designer</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Libre+Franklin:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/global.css" />
	<link rel="stylesheet" href="css/portfolio.css" />
	<link rel="stylesheet" href="css/style.css" />
</head>

<body>
	<!-- ============================================================ -->
	<!-- MENU  +  SECTION 1 (HERO HEADER)                             -->
	<!-- ============================================================ -->
	<header class="header" id="section1">
		<img src="assets/header-bullet-points.png" class="header-bullet-points" alt="" />

		<div class="header-img1">
			<div class="circle header-circle"></div>
			<img src="assets/header-img.png" class="header-img2" alt="Arlene Rey" />
		</div>

		<!-- ===== MENU / NAVIGATION BAR ===== -->
		<nav class="header-nav-bar">
			<h2 class="header-subtitle1"><a href="index.php">Arlene Rey</a></h2>

			<button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false">
				<span></span><span></span><span></span>
			</button>

			<div class="header-menu" id="navMenu">
				<a class="header-text-about" href="#section1">About</a>
				<a class="header-text1" href="#section3">Testimonials</a>
				<?php if (is_logged_in()): ?>
					<a class="header-text-login" href="admin.php">Dashboard</a>
					<a class="header-text-login" href="logout.php">Log Out (<?= e(current_user_name()) ?>)</a>
				<?php else: ?>
					<a class="header-text-login" href="login.php">Log In</a>
				<?php endif; ?>
			</div>
		</nav>

		<!-- ===== HERO CONTENT ===== -->
		<div class="header-text2">
			<h2 class="header-subtitle-hey-exclamation heading1">Hey!</h2>

			<div class="header-row">
				<h2 class="header-subtitle-i-m-an-ui-ux heading2">
					I'm <br />
					an UI/UX Designer.
				</h2>
				<h2 class="header-subtitle2 heading2">A</h2>
			</div>

			<img src="assets/header-line.png" class="header-line" alt="" />
			<p class="header-text-ux-designer">
				UX Designer based in Jakarta, Indonesia.<br />
				I am designing with a minimal and beautiful design in mind.
			</p>

			<div class="header-social-icon">
				<p class="header-text-left body-text">Follow Me: </p>
				<a href="#"><img src="assets/header-icons1.png" class="header-icons" alt="Instagram" /></a>
				<a href="#"><img src="assets/header-icons2.png" class="header-icons" alt="YouTube" /></a>
				<a href="#"><img src="assets/header-icons3.png" class="header-icons" alt="Dribbble" /></a>
			</div>
		</div>

		<div class="header-row-bottom">
			<a href="mailto:arlene@example.com" class="btn1 hover-dark">
				<img src="assets/btn-icon.png" class="btn-icon-s-mail-a btn-icon1" alt="" />
				<span class="btn-label1">Mail Me</span>
			</a>

			<a href="#" class="btn2 hover-zoom">
				<img src="assets/btn-icon2.png" class="btn-icon-s-download btn-icon2" alt="" />
				<span class="btn-label2">Download CV</span>
			</a>
		</div>
	</header>

	<!-- ============================================================ -->
	<!-- SECTION 2 (REVIEW / INFO)  — DATA FROM DATABASE              -->
	<!-- ============================================================ -->
	<section class="info" id="section2">
		<div class="circle info-circle"></div>
		<img src="assets/header-bullet-points.png" class="info-bullet-points" alt="" />

		<div class="info-review">
			<img src="<?= e($info['image']) ?>" class="info-img" alt="<?= e($info['heading']) ?>" />

			<div class="info-col-right">
				<div class="info-row-top1">
					<div class="info-completed">
						<h1 class="info-title"><?= e($info['completed_projects']) ?><span class="sub-text-green">+</span></h1>
						<h2 class="info-subtitle-completed"><?= e($info['projects_label']) ?></h2>
					</div>

					<div class="info-positive">
						<div class="info-row-top2">
							<h2 class="info-subtitle-a-plus heading3"><?= e($info['rating_grade']) ?></h2>
							<div class="info-rating">
								<?= render_stars((float) $info['rating_stars']) ?>
							</div>
						</div>
						<h2><?= e($info['rating_label']) ?></h2>
					</div>
				</div>

				<h2 class="info-subtitle"><?= e($info['heading']) ?></h2>
				<p class="info-text"><?= e($info['description']) ?></p>

				<a href="mailto:arlene@example.com" class="btn3 hover-dark">
					<img src="assets/btn-icon.png" class="btn-icon-s-mail-b btn-icon3" alt="" />
					<span class="btn-label3"><?= e($info['button_label']) ?></span>
				</a>
			</div>
		</div>
	</section>

	<!-- ============================================================ -->
	<!-- SECTION 3 (TESTIMONIALS) — DATA FROM DB + INTERACTIVE SLIDER -->
	<!-- ============================================================ -->
	<section class="footer" id="section3">
		<h2 class="footer-subtitle">We Are Loved By Users And Clients Worldwide</h2>

		<div class="frame frame1">
			<div class="carousel" id="carousel">
				<div class="carousel-track" id="testimonialTrack">
					<?php foreach ($testimonials as $t): ?>
						<article class="card-testimonial">
							<h2 class="card-testimonial-subtitle"><?= e($t['message']) ?></h2>

							<div class="card-testimonial-profile">
								<img src="<?= e($t['image']) ?>" class="card-testimonial-pic" alt="<?= e($t['name']) ?>" />

								<div class="card-testimonial-col">
									<p class="card-testimonial-text-name"><?= e($t['name']) ?></p>
									<p class="card-testimonial-text-role"><?= e($t['role']) ?></p>
								</div>

								<div class="card-testimonial-meta">
									<p class="card-testimonial-text-value"><?= e(rtrim(rtrim(number_format((float) $t['rating'], 1), '0'), '.')) ?></p>
									<div class="card-testimonial-rating-stars"><?= render_stars((float) $t['rating']) ?></div>
								</div>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- interactive controls -->
			<div class="carousel-controls">
				<button class="carousel-btn" id="carouselPrev" aria-label="Previous testimonials">&#8249;</button>
				<div class="frame-slider-dot" id="carouselDots"></div>
				<button class="carousel-btn" id="carouselNext" aria-label="Next testimonials">&#8250;</button>
			</div>
		</div>
	</section>

	<!-- ============================================================ -->
	<!-- PAGE FOOTER (SUBSOL)                                         -->
	<!-- ============================================================ -->
	<footer class="site-footer">
		<div class="site-footer-inner">
			<div class="site-footer-col">
				<h3 class="site-footer-brand">Arlene Rey</h3>
				<p class="site-footer-text">UI/UX Designer based in Jakarta, Indonesia. Designing with a minimal and beautiful mindset.</p>
			</div>

			<div class="site-footer-col">
				<h4 class="site-footer-title">Navigation</h4>
				<a href="#section1">About</a>
				<a href="#section2">Reviews</a>
				<a href="#section3">Testimonials</a>
				<?php if (is_logged_in()): ?>
					<a href="admin.php">Dashboard</a>
				<?php else: ?>
					<a href="login.php">Log In</a>
				<?php endif; ?>
			</div>

			<div class="site-footer-col">
				<h4 class="site-footer-title">Contact</h4>
				<a href="mailto:arlene@example.com">arlene@example.com</a>
				<a href="tel:+621234567890">+62 123 456 7890</a>
				<div class="site-footer-social">
					<a href="#"><img src="assets/header-icons1.png" alt="Instagram" /></a>
					<a href="#"><img src="assets/header-icons2.png" alt="YouTube" /></a>
					<a href="#"><img src="assets/header-icons3.png" alt="Dribbble" /></a>
				</div>
			</div>
		</div>

		<div class="site-footer-bottom">
			<p>&copy; <?= date('Y') ?> Arlene Rey. All rights reserved. — Built by Cristi Durlesteanu.</p>
		</div>
	</footer>

	<script src="js/main.js"></script>
</body>
</html>
