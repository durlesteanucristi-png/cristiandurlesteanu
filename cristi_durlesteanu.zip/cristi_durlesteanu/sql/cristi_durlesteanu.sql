-- ============================================================
--  Database : cristi_durlesteanu
--  Portfolio website - users, section 2 (site_info) & testimonials
-- ============================================================

CREATE DATABASE IF NOT EXISTS cristi_durlesteanu
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cristi_durlesteanu;

-- ------------------------------------------------------------
--  Table: users  (login / register)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    email      VARCHAR(150)  NOT NULL UNIQUE,
    password   VARCHAR(255)  NOT NULL,
    created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default admin account  ->  email: admin@cristi.com   password: admin123
INSERT INTO users (name, email, password) VALUES
('Administrator', 'admin@cristi.com', '$2y$10$5Xdsk.JtK0R4y6GYRxPl1O6.RoCmgXqjv5UPa76bZpkFYuir2b6ve');

-- ------------------------------------------------------------
--  Table: site_info  (SECTION 2 - "Review" block)
--  Single editable record that drives the whole section.
-- ------------------------------------------------------------
DROP TABLE IF EXISTS site_info;
CREATE TABLE site_info (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    completed_projects INT          NOT NULL DEFAULT 120,
    projects_label     VARCHAR(120) NOT NULL DEFAULT 'Completed Projects',
    rating_grade       VARCHAR(10)  NOT NULL DEFAULT 'A+',
    rating_stars       TINYINT      NOT NULL DEFAULT 5,
    rating_label       VARCHAR(120) NOT NULL DEFAULT 'Positive Reviews',
    heading            VARCHAR(150) NOT NULL DEFAULT 'Glad to Help You!',
    description        TEXT         NOT NULL,
    image              VARCHAR(255) NOT NULL DEFAULT 'assets/info-img.png',
    button_label       VARCHAR(60)  NOT NULL DEFAULT 'Contact Me'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO site_info
    (completed_projects, projects_label, rating_grade, rating_stars, rating_label, heading, description, image, button_label)
VALUES
    (120, 'Completed Projects', 'A+', 5, 'Positive Reviews', 'Glad to Help You!',
     'As a full-service digital designer, I work closely with my clients to define, design and develop transformative user experiences across all platforms and brand''s touchpoints.',
     'assets/info-img.png', 'Contact Me');

-- ------------------------------------------------------------
--  Table: testimonials  (SECTION 3 - "We Are Loved By Users")
-- ------------------------------------------------------------
DROP TABLE IF EXISTS testimonials;
CREATE TABLE testimonials (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    role       VARCHAR(100)  NOT NULL,
    message    TEXT          NOT NULL,
    rating     DECIMAL(2,1)  NOT NULL DEFAULT 5.0,
    image      VARCHAR(255)  NOT NULL DEFAULT 'assets/card-testimonial-profile/card-testimonial-pic1.png',
    created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO testimonials (name, role, message, rating, image) VALUES
('Ronald Richards', 'UI/UX Designer',
 'Working with Ariene was an absolute game-changer for our startup. She delivered a minimal and beautifully crafted interface that our users love.',
 4.5, 'assets/card-testimonial-profile/card-testimonial-pic1.png'),
('Athena Jhones', 'Product Owner',
 'Ariene isn''t just a designer who hands off files; she is a true partner. Her strategic approach led to a truly transformative user experience.',
 5.0, 'assets/card-testimonial-profile/card-testimonial-pic2.png'),
('Donald Duck', 'Project Manager',
 'Had an amazing experience working with Ariene! She definitely added a unique touch to our project.',
 4.5, 'assets/card-testimonial-profile/card-testimonial-pic1.png'),
('Olya Reeves', 'UI/UX Designer',
 'Ariene handled the complexity with ease, ensuring a seamless and beautiful experience across all platforms.',
 4.5, 'assets/card-testimonial-profile/card-testimonial-pic2.png'),
('Thomas Jefferson', 'CEO Built',
 'Ariene''s experience and professionalism shine through in every interaction. She is responsive, reliable, and consistently delivers A+ work.',
 5.0, 'assets/card-testimonial-profile/card-testimonial-pic1.png'),
('Hugh Jackman', 'Actor',
 'I was blown away by Ariene''s attention to detail and her willingness to listen. She genuinely cares about her clients'' success.',
 4.0, 'assets/card-testimonial-profile/card-testimonial-pic2.png');
