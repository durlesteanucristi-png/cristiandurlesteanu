<?php
/**
 * Shared helpers: session bootstrap, escaping, auth checks, star rendering.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Escape output for safe HTML rendering. */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** Is a user currently logged in? */
function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

/** Get the logged-in user's display name (or null). */
function current_user_name(): ?string
{
    return $_SESSION['user_name'] ?? null;
}

/** Redirect to the login page if the visitor is not authenticated. */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Render a 5-star rating driven by a numeric value taken from the database.
 * Uses a precise fractional fill (e.g. 4.5 -> 90% gold) via CSS ::before/::after.
 */
function render_stars(float $rating): string
{
    $pct = max(0.0, min(100.0, ($rating / 5) * 100));
    return '<span class="stars" role="img" aria-label="' . e($rating) . ' out of 5 stars" '
        . 'style="--pct:' . e(round($pct, 2)) . '%"></span>';
}
