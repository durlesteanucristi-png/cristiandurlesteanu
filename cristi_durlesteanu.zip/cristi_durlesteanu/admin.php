<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

require_login();

// CSRF token
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function set_flash(string $msg, string $type = 'success'): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

// Available profile images for testimonials
$profileImages = [
    'assets/card-testimonial-profile/card-testimonial-pic1.png',
    'assets/card-testimonial-profile/card-testimonial-pic2.png',
];

/* ============================================================
   HANDLE FORM SUBMISSIONS (Create / Update / Delete)  — PRG
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf'] ?? '')) {
        set_flash('Security token mismatch. Please try again.', 'error');
        header('Location: admin.php');
        exit;
    }

    $action = $_POST['action'] ?? '';

    /* ---- SECTION 2: update site_info (Read + Modify) ---- */
    if ($action === 'update_info') {
        $completed    = (int) ($_POST['completed_projects'] ?? 0);
        $projectsLbl  = trim($_POST['projects_label'] ?? '');
        $grade        = trim($_POST['rating_grade'] ?? '');
        $stars        = (int) ($_POST['rating_stars'] ?? 5);
        $ratingLbl    = trim($_POST['rating_label'] ?? '');
        $heading      = trim($_POST['heading'] ?? '');
        $description  = trim($_POST['description'] ?? '');
        $image        = trim($_POST['image'] ?? '');
        $buttonLbl    = trim($_POST['button_label'] ?? '');
        $stars = max(0, min(5, $stars));

        if ($heading === '' || $description === '') {
            set_flash('Heading and description are required.', 'error');
        } else {
            $stmt = $pdo->prepare(
                'UPDATE site_info SET completed_projects=?, projects_label=?, rating_grade=?,
                 rating_stars=?, rating_label=?, heading=?, description=?, image=?, button_label=?
                 WHERE id=?'
            );
            $stmt->execute([$completed, $projectsLbl, $grade, $stars, $ratingLbl,
                $heading, $description, $image, $buttonLbl, (int) $_POST['id']]);
            set_flash('Section 2 (Review) updated successfully.');
        }
        header('Location: admin.php#section2-panel');
        exit;
    }

    /* ---- SECTION 3: add testimonial (Create) ---- */
    if ($action === 'add_testimonial') {
        $name    = trim($_POST['name'] ?? '');
        $role    = trim($_POST['role'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $rating  = (float) ($_POST['rating'] ?? 5);
        $image   = trim($_POST['image'] ?? $profileImages[0]);
        $rating  = max(0, min(5, $rating));

        if ($name === '' || $role === '' || $message === '') {
            set_flash('Name, role and message are required.', 'error');
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO testimonials (name, role, message, rating, image) VALUES (?,?,?,?,?)'
            );
            $stmt->execute([$name, $role, $message, $rating, $image]);
            set_flash('Testimonial added successfully.');
        }
        header('Location: admin.php#section3-panel');
        exit;
    }

    /* ---- SECTION 3: update testimonial (Modify) ---- */
    if ($action === 'update_testimonial') {
        $id      = (int) ($_POST['id'] ?? 0);
        $name    = trim($_POST['name'] ?? '');
        $role    = trim($_POST['role'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $rating  = (float) ($_POST['rating'] ?? 5);
        $image   = trim($_POST['image'] ?? $profileImages[0]);
        $rating  = max(0, min(5, $rating));

        if ($id <= 0 || $name === '' || $role === '' || $message === '') {
            set_flash('Name, role and message are required.', 'error');
        } else {
            $stmt = $pdo->prepare(
                'UPDATE testimonials SET name=?, role=?, message=?, rating=?, image=? WHERE id=?'
            );
            $stmt->execute([$name, $role, $message, $rating, $image, $id]);
            set_flash('Testimonial updated successfully.');
        }
        header('Location: admin.php#section3-panel');
        exit;
    }

    /* ---- SECTION 3: delete testimonial (Delete) ---- */
    if ($action === 'delete_testimonial') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM testimonials WHERE id = ?');
        $stmt->execute([$id]);
        set_flash('Testimonial deleted.');
        header('Location: admin.php#section3-panel');
        exit;
    }

    header('Location: admin.php');
    exit;
}

/* ============================================================
   LOAD DATA (Read)
   ============================================================ */
$info = $pdo->query('SELECT * FROM site_info ORDER BY id LIMIT 1')->fetch();
$testimonials = $pdo->query('SELECT * FROM testimonials ORDER BY id DESC')->fetchAll();

$editing = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM testimonials WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editing = $stmt->fetch() ?: null;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Dashboard — Arlene Rey</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/reset.css" />
	<link rel="stylesheet" href="css/style.css" />
	<link rel="stylesheet" href="css/admin.css" />
</head>
<body class="admin-body">
	<header class="admin-topbar">
		<div class="admin-topbar-inner">
			<h1 class="admin-logo">Arlene Rey <span>Dashboard</span></h1>
			<div class="admin-topbar-actions">
				<span class="admin-user">Hi, <?= e(current_user_name()) ?></span>
				<a class="admin-link" href="index.php" target="_blank">View site &#8599;</a>
				<a class="admin-btn-logout" href="logout.php">Log out</a>
			</div>
		</div>
	</header>

	<main class="admin-main">

		<?php if ($flash): ?>
			<div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : 'success' ?>">
				<?= e($flash['msg']) ?>
			</div>
		<?php endif; ?>

		<!-- ============ SECTION 2 EDITOR (site_info) ============ -->
		<section class="admin-panel" id="section2-panel">
			<h2 class="admin-panel-title">Section 2 — Review block</h2>
			<p class="admin-panel-sub">This content is pulled from the database into Section 2 of the homepage.</p>

			<form method="post" action="admin.php" class="admin-form">
				<input type="hidden" name="csrf" value="<?= e($csrf) ?>" />
				<input type="hidden" name="action" value="update_info" />
				<input type="hidden" name="id" value="<?= e($info['id']) ?>" />

				<div class="admin-grid">
					<div class="field">
						<label>Completed projects (number)</label>
						<input type="number" name="completed_projects" value="<?= e($info['completed_projects']) ?>" min="0" />
					</div>
					<div class="field">
						<label>Projects label</label>
						<input type="text" name="projects_label" value="<?= e($info['projects_label']) ?>" />
					</div>
					<div class="field">
						<label>Rating grade (e.g. A+)</label>
						<input type="text" name="rating_grade" value="<?= e($info['rating_grade']) ?>" />
					</div>
					<div class="field">
						<label>Rating stars (0–5)</label>
						<input type="number" name="rating_stars" value="<?= e($info['rating_stars']) ?>" min="0" max="5" step="1" />
					</div>
					<div class="field">
						<label>Rating label</label>
						<input type="text" name="rating_label" value="<?= e($info['rating_label']) ?>" />
					</div>
					<div class="field">
						<label>Button label</label>
						<input type="text" name="button_label" value="<?= e($info['button_label']) ?>" />
					</div>
					<div class="field">
						<label>Heading</label>
						<input type="text" name="heading" value="<?= e($info['heading']) ?>" />
					</div>
					<div class="field">
						<label>Image path</label>
						<input type="text" name="image" value="<?= e($info['image']) ?>" />
					</div>
				</div>
				<div class="field">
					<label>Description</label>
					<textarea name="description" rows="3"><?= e($info['description']) ?></textarea>
				</div>

				<button type="submit" class="btn-primary admin-save">Save Section 2</button>
			</form>
		</section>

		<!-- ============ SECTION 3 MANAGER (testimonials CRUD) ============ -->
		<section class="admin-panel" id="section3-panel">
			<h2 class="admin-panel-title">Section 3 — Testimonials</h2>
			<p class="admin-panel-sub">Create, edit and delete the testimonials shown in the Section 3 carousel.</p>

			<!-- Add / Edit form -->
			<form method="post" action="admin.php" class="admin-form admin-form-boxed">
				<input type="hidden" name="csrf" value="<?= e($csrf) ?>" />
				<input type="hidden" name="action" value="<?= $editing ? 'update_testimonial' : 'add_testimonial' ?>" />
				<?php if ($editing): ?>
					<input type="hidden" name="id" value="<?= e($editing['id']) ?>" />
				<?php endif; ?>

				<h3 class="admin-form-title"><?= $editing ? 'Edit testimonial #' . e($editing['id']) : 'Add new testimonial' ?></h3>

				<div class="admin-grid">
					<div class="field">
						<label>Name</label>
						<input type="text" name="name" value="<?= e($editing['name'] ?? '') ?>" required />
					</div>
					<div class="field">
						<label>Role</label>
						<input type="text" name="role" value="<?= e($editing['role'] ?? '') ?>" required />
					</div>
					<div class="field">
						<label>Rating (0–5)</label>
						<input type="number" name="rating" value="<?= e($editing['rating'] ?? '5.0') ?>" min="0" max="5" step="0.5" />
					</div>
					<div class="field">
						<label>Profile image</label>
						<select name="image">
							<?php foreach ($profileImages as $img): ?>
								<option value="<?= e($img) ?>" <?= (($editing['image'] ?? '') === $img) ? 'selected' : '' ?>>
									<?= e(basename($img)) ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="field">
					<label>Message</label>
					<textarea name="message" rows="3" required><?= e($editing['message'] ?? '') ?></textarea>
				</div>

				<div class="admin-form-actions">
					<button type="submit" class="btn-primary admin-save">
						<?= $editing ? 'Update testimonial' : 'Add testimonial' ?>
					</button>
					<?php if ($editing): ?>
						<a href="admin.php#section3-panel" class="admin-cancel">Cancel</a>
					<?php endif; ?>
				</div>
			</form>

			<!-- List (Read) -->
			<div class="admin-table-wrap">
				<table class="admin-table">
					<thead>
						<tr>
							<th>#</th>
							<th>Photo</th>
							<th>Name / Role</th>
							<th>Message</th>
							<th>Rating</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php if (!$testimonials): ?>
							<tr><td colspan="6" class="admin-empty">No testimonials yet. Add the first one above.</td></tr>
						<?php endif; ?>
						<?php foreach ($testimonials as $t): ?>
							<tr>
								<td><?= e($t['id']) ?></td>
								<td><img class="admin-thumb" src="<?= e($t['image']) ?>" alt="<?= e($t['name']) ?>" /></td>
								<td>
									<strong><?= e($t['name']) ?></strong><br />
									<span class="admin-muted"><?= e($t['role']) ?></span>
								</td>
								<td class="admin-msg"><?= e($t['message']) ?></td>
								<td><?= e(number_format((float) $t['rating'], 1)) ?> &#9733;</td>
								<td class="admin-actions">
									<a class="admin-action edit" href="admin.php?edit=<?= e($t['id']) ?>#section3-panel">Edit</a>
									<form method="post" action="admin.php" onsubmit="return confirm('Delete this testimonial?');" style="display:inline">
										<input type="hidden" name="csrf" value="<?= e($csrf) ?>" />
										<input type="hidden" name="action" value="delete_testimonial" />
										<input type="hidden" name="id" value="<?= e($t['id']) ?>" />
										<button type="submit" class="admin-action delete">Delete</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</section>
	</main>
</body>
</html>
